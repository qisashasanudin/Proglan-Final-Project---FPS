#ifndef _BMP_H
#define _BMP_H

#include "main.h"


void BMP_Texture(UINT textureArray[], LPSTR strFileName, int ID);



#endif

//Ronny Andr� Reierstad
//www.morrowland.com
//apron@morrowland.com