# BoulderBlastGame
C++ OpenGL and GLUT third person shooter game

This project was one of the most fun projects I have ever done in a CS course.  The purpose of this project was to teach about Object-Oriented design principles, including Encapsulation, Inheritance, and Polymorphism through design of my own classes to implement functionality for the game.  I learned about OpenGL and GLUT, as well as some computer game mechanics.  Furthermore, I learned how to debug larger software solutions using Xcode.
