#ifndef _MAIN_H
#define _MAIN_H

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")


#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>
#include <fstream>
#include <vector>									
#include <crtdbg.h>
using namespace std;


													

//////////////////////////////////////
//The CVector Class
//////////////////////////////////////
class CVector											
{
	public:
		float x, y, z;
};

//////////////////////////////////////
//The CVector3 Struct
//////////////////////////////////////
class CVector3
{
	public:

		CVector3() {}
		
		CVector3(float X, float Y, float Z) 
		{ 
			x = X; y = Y; z = Z;
		}
		
		CVector3 operator+(CVector3 vVector)
		{
			return CVector3(vVector.x + x, vVector.y + y, vVector.z + z);
		}
		
		CVector3 operator-(CVector3 vVector)
		{
			return CVector3(x - vVector.x, y - vVector.y, z - vVector.z);
		}
		
		CVector3 operator*(float num)
		{
			return CVector3(x * num, y * num, z * num);
		}
		
		float x, y, z;						
};

//////////////////////////////////////
//The Global Variables
//////////////////////////////////////
extern	HDC			hDC;			// Device Context
extern	HGLRC		hRC;			// Permanent Rendering Context
extern	HWND		hWnd;			// Holds Our Window Handle
extern	HINSTANCE	hInstance;		// Holds The Instance Of The Application




//////////////////////////////////////
//The Main Functions
//////////////////////////////////////
void Keyboard_Input();
void Unload();



#endif