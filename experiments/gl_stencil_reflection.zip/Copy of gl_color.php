
<!-- MORROWLAND PRODUCT-->
<?
     if($open=="")
     {
	$name   ="gl_color";
	$right  ="gl";
	$title  ="OPENGL COLOR";
	$back="../../";


	$open="true";

	include "../../main.php";

	exit();
     }


?>








<? include  $back.'code.php'; ?>
	

<table width="200" border="0" cellspacing="0" cellpadding="0">
<tr><td><img src="../../images/tutorials/gl/tut_gllogo.jpg"></td></tr>
</table>

<hr size="1" noshade>

<form id="formDemo" name="formDemo">
<textarea cols="0" rows="1" name="sourceCode" id="sourceCode"></textarea>
<script language="javascript">document.formDemo.sourceCode.style.display='none';</script>
</form>




<center>



<xml id="CodeID">
<codes>






<code id="code_6">
<![CDATA[
<pre lang="cpp">
int DrawGLScene(GLvoid)		// Here's Where We Do All The Drawing
{
    // Clear Screen And Depth Buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // Reset The Current Modelview Matrix
    glLoadIdentity();

//NEW//////////////////NEW//////////////////NEW//////////////////NEW/////////////

    glTranslatef(0.0f, 0.0f, -6.0f);		// Translate Into The Screen
    glBegin(GL_TRIANGLES);			// Start Drawing A Triangle
	glColor3f( 1.0f,0.0f,0.0f);		// Red Color
	glVertex3f(0.0f, 1.0f, 0.0f);	// Top Color
	glColor3f(0.0f,1.0f,0.0f);		// Green
	glVertex3f(-1.0f,-1.0f, 0.0f);	// Bottom Left Vertex
	glColor3f(0.0f,0.0f,1.0f);		// Blue Color
	glVertex3f( 1.0f,-1.0f, 0.0f);	// Bottom Right Vertex
    glEnd();				// Finished Drawing The Triangle


//NEW//////////////////NEW//////////////////NEW//////////////////NEW/////////////

    return TRUE;			// Keep Going
}
</pre>
]]>
</code>











</codes>
</xml>





<? Begin_gltut(585); ?>
<h1>OPENGL COLOR TUTORIAL</h1>
<? End_gltut(); ?>




<? Begin_gltut(585); ?>
All we are going to do in this tutorial is apply a color to our triangle. To be more specific we are going to apply a different color to each vertex by using the
glColor3f(red, green, blue) function. The color values range from 0.0f to 1.0f. 0.0f being the darkest and 1. 0f being the brightest. The glColor3f uses RGB values and the glColor4f uses RGBA values. The first parameter is the Red Intensity, the second parameter is for Green and the third is for Blue. The closer the value of the number is to 1.0f, the brighter that specific color will be. The last number is an Alpha value.
Blending green and blue creates shades of cyan. Blue and red combine for magenta. Red and green create yellow.
<br><br>
glColor3f (1.0f, 0.0f, 0.0f);  full red, no green, no blue.
<br><br>
glColor3f (0.0f, 1.0f, 0.0f);  no red, full green, no blue.
<br><br>
glColor3f (0.0f, 0.0f, 1.0f);  no red, no green, full blue.


<? End_gltut(); ?>


<? Begin_gltut(585); ?><br><font color="black">
 <? cpp_code("code_6"); ?>
</font><? End_gltut(); ?>









<? Begin_gltut(585); ?>
If you have managed to draw a triangle, colouring it is no problem...
<br><br>





Regards<br>
Ronny Andr� Reierstad<br>
<br><br>
<hr size="1" noshade>
<table border="0"  width="585" cellspacing="0" cellpadding="0">
  <tr><td><a href="gl_color.zip"><img src="../../images/tutorials/main/tut_file.gif" alt="Download Source Code!" border="0"></td>
  <td valign="center"><font face="verdana" size="4">Visual Studio C++ Source Code</font></td>
</tr>
</table>
<hr size="1" noshade>
</center><br>


<? End_gltut(); ?>


















