#ifndef _MAIN_H
#define _MAIN_H


#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")


#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#include "bmp.h"

//NEW//////////////////NEW//////////////////NEW//////////////////NEW////////////////

// Texture Array for method I
GLfloat texCoords[]={	1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f,
								0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
								1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
								0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
								0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
								1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0};
// Vertex Array for method I
GLfloat vertexPositions[]={			-1.0f, -1.0f,  1.0f, -1.0f,  1.0f,  1.0f,
									 1.0f,  1.0f,  1.0f,  1.0f, -1.0f,  1.0f,
									-1.0f, -1.0f, -1.0f,  1.0f, -1.0f, -1.0f,
									 1.0f,  1.0f, -1.0f, -1.0f,  1.0f, -1.0f,
									-1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f,
									 1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f,
									-1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,
									 1.0f, -1.0f,  1.0f,  1.0f, -1.0f, -1.0f,
									 1.0f, -1.0f, -1.0f,  1.0f, -1.0f,  1.0f,
									 1.0f,  1.0f,  1.0f,  1.0f,  1.0f, -1.0f,
									-1.0f, -1.0f, -1.0f, -1.0f,  1.0f, -1.0f,
									-1.0f,  1.0f,  1.0f, -1.0f, -1.0f,  1.0f};


// Vertex Array for method II
GLfloat vertices[] = { -1.0f, 1.0f, 1.0f,    //front
				        1.0f, 1.0f, 1.0f,    //1
				        1.0f,-1.0f, 1.0f,    //2
				       -1.0f,-1.0f, 1.0f,    //3
				       -1.0f, 1.0f,-1.0f,    //4
				        1.0f, 1.0f,-1.0f,    //5
				        1.0f,-1.0f,-1.0f,    //6
				       -1.0f,-1.0f,-1.0f  }; //7

// Index Array for method II
GLubyte indices[] = {	0, 1, 2, 3,		//front
						4, 5, 1, 0,		//top
						3, 2, 6, 7,		//bottom
						5, 4, 7, 6,		//back
						1, 5, 6, 2,		//right
						4, 0, 3, 7  };	//left



//NEW//////////////////NEW//////////////////NEW//////////////////NEW////////////////


//////////////////////////////////////
//The Global Variables
//////////////////////////////////////
extern	HDC			hDC;			// Device Context
extern	HGLRC		hRC;			// Permanent Rendering Context
extern	HWND		hWnd;			// Holds Our Window Handle
extern	HINSTANCE	hInstance;		// Holds The Instance Of The Application





#endif

//Ronny Andr� Reierstad
//www.morrowland.com
//apron@morrowland.com